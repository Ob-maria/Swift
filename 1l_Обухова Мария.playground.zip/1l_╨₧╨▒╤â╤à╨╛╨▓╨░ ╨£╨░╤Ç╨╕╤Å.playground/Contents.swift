import UIKit

//1. Решить квадратное уравнение.

let a:Double = -1
let b:Double = -2
let c:Double = 15
var D:Double = (b * b) - 4 * a * c
var x1:Double = 0
var x2:Double = 0

if D > 0 {
    x1 = (-b + sqrt(D))/(2 * a)
    x2 = (-b - sqrt(D))/(2 * a)
    print("Первый корень равен", x1)
    print ("Второй корень равен", x2)
} else if D == 0 {
    x1 = (-b + sqrt(D))/(2 * a)
    print ("Корень равен", x1)
} else {
    print ("Уравнение не имеет корней")
}

//2. Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.

let a1:Double = 6
let b1:Double = 8
var c1:Double = a1 * a1 + b1 * b1
c1 = sqrt(c1)
var S:Double =  a1 * c1 * 1/2
var P:Double = a1 + b1 + c1
print ("Гипотенузу треугольника равна", c1)
print ("Площадь равна", S)
print ("Периметр равен", P)

//3. * Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.
var sum:Double = 30000
let pr:Double = 10
var g:Double = 0

for _ in 1...5 {
    g = (sum * pr)/100
    sum = sum + g
}
print ("Сумма вклада через пять лет будет:", sum)
